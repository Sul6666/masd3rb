echo "
             root3rb
╗────────────────────────────────────────╔
      au_z3@
      El_awawni@
      ───────────────────╚
"
sleep 2
echo   " ✅ Automatic update from Arab Root ✅"
ping -w 1 google.com &>/dev/null
if [ $? -ne 0 ]; then
    echo "   مرحبآ في روت العرب 🚥 الرجاء التأكد من حاله الإنترنت لديك 🚧 "
    sleep 2
    exit 1
fi

# Download Strong File By @root3rb ✅"
        curl -o /data/adb/tricky_store/keybox.xml https://raw.githubusercontent.com/Sul6666/msup/refs/heads/main/key.xml
        curl -o /data/adb/pif.json https://raw.githubusercontent.com/Sul6666/msup/refs/heads/main/pif.json
        curl -o /data/adb/tricky_store/target.txt https://raw.githubusercontent.com/Sul6666/msup/refs/heads/main/target.txt
echo
echo
echo
echo " 🚨 لمتابعة كل جديد انضم الى القناة الخاصه بنا 💻"
sleep 4
echo "▬▬▬.◙.▬▬▬"
echo "═▂▄▄▓▄▄▂"
echo "◢◤ █▀▀████▄▄▄▄◢◤"
echo "█▄ █ █▄ ███▀▀▀▀▀▀▀╬"
echo "◥█████◤"
echo "══╩══╩═"
echo "╬═╬"
echo "╬═╬"
echo "╬═╬"
echo "╬═╬"
echo "╬═╬☻/ Finishing installation"
echo "╬═╬/▌ ✅ تم التحديث بنجاح✅🆙 "
echo "╬═╬/ \ "
echo " "
sleep 1
nohup am start -a android.intent.action.VIEW -d https://t.me/root3rb >/dev/null 2>&1 &
echo
echo
echo "            ROOT3RB "
echo
echo  
sleep_pause